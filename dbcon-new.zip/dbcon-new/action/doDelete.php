<?php
	$link=mysqli_connect("localhost","root","","company");
	$q="delete from emp where empno='".$_GET['id']."'";
	$r=mysqli_query($link,$q);
	if(!$r){
		die("could not delete".mysqli_errno()."-".mysqli_error());
	}
	else{
		echo "deleted successfully!!";
	}
	mysqli_close($link);
	echo "<p><a href='../index.php'>click here to move to previous page!!</a></p>";
?>