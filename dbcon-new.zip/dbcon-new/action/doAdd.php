<?php
	print_r($_POST);
	if (isset($_POST['sub'])) {
		$name=$_POST['ename'];
		$sal=$_POST['esal'];
		$stat=$_POST['estatus'];
		$link=@mysqli_connect("localhost","root","","company");
		if (!$link) {
			die("cannot connect to databse:".mysqli_connect_errno()."-".mysqli_connect_error());
		}
		else{
			$q="insert into emp(ename,sal,status) values('".$name."','".$sal."','".$stat."')";
			$r=mysqli_query($link,$q);
			if($r){
				echo "<p>employee added successfully!!!</p>";
			}
			else{
				echo "Not added";
			}
		}
		mysqli_close($link);
	}
	echo "<p><a href='../index.php'>click here to go to main page</a></p>";
	?>