<?php
	if (isset($_POST['sub'])) {
		$name=$_POST['ename'];
		$sal=$_POST['esal'];
		$status=$_POST['estatus'];
		$l=mysqli_connect("localhost","root","","company");
		$q="update emp set ename='".$name."',sal='".$sal."',status='".$status."' where empno='".$_POST['empid']."'";
		$r=mysqli_query($l,$q);
		if ($r) {
			echo "Employee updated successfully!!";
		}else{
			echo "Cannot update";
		}
		mysqli_close($l);
	}
	echo "<p><a href='../index.php'>click here to go to main page!!</a></p>";
?>