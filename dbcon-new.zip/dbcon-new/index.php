<!DOCTYPE html>
<html>
<head>
	<title>Database CRUD ops</title>
</head>
<body>
<?php
	if (isset($_GET['id'])) {
		$l=mysqli_connect("localhost","root","","company");
		$q="select * from emp where empno='".$_GET['id']."'";
		$res=mysqli_query($l,$q);
		$r=mysqli_fetch_assoc($res);
	}
?>
<form method="POST" action="<?php if(isset($_GET['id'])){ echo "action/doUpdate.php";}else{echo "action/doAdd.php";}?>">
	<?php
		if (isset($_GET['id'])) {
			?>
			<input type="hidden" name="empid" value="<?php echo $_GET['id'];?>">
			<?php } ?>
	<table>
		<tr>
			<td>Employee Name:</td>
			<td><input type="text" name="ename" value="<?php if(isset($_GET['id'])){echo $r['ename'];}?>" placeholder="Employee Name"></td>
		</tr>
		<tr>
			<td>Salary:</td>
			<td><input type="number" name="esal" placeholder="Salary" value="<?php if(isset($_GET['id'])){echo $r['sal'];}?>"></td>
		</tr>
		<tr>
			<td>Status:</td>
			<td>
				<select name="estatus">
				<option value="Active"
					<?php if (isset($r['status']) && $r['status']=="Active") {
						echo "selected";
					}?>
				>Active
				</option>
				<option value="Inactive"
					<?php if (isset($r['status']) && $r['status']=="Inactive") {
						echo "selected";
					}?>
				>Inactive</option>
				<option value="Delete"
					<?php if (isset($r['status']) && $r['status']=="Delete") {
						echo "selected";
					}?>
				>Delete</option>
			</select>
			</td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="sub" value="<?php if(isset($_GET['id'])){echo "Update";}else{echo "Add";}?>"></td>
		</tr>
	</table>
	</form>
	<hr>
	<?php
		$link=@mysqli_connect("localhost","root","","company");
		if (!$link) {
			die("cannot connect to databse:".mysqli_connect_errno()."-".mysqli_connect_error());
		}
		else{
			$q="select * from emp;";
			$r=mysqli_query($link,$q);
			if (mysqli_num_rows($r)>0) {
				?>
				<table border="1">
					<tr>
						<td>Employee No.</td>
						<td>Employee Name.</td>
						<td>Salary</td>
						<td>Status</td>
						<td colspan="2">Action</td>
					</tr>
					<?php
				while ($row=mysqli_fetch_assoc($r)) {
					?>
					<tr>
						<td><?php echo $row['empno'] ?></td>
						<td><?php echo $row['ename'] ?></td>
						<td><?php echo $row['sal'] ?></td>
						<td><?php echo $row['status'] ?></td>
						<td><a href="?id=<?php echo $row['empno']?>">Edit</a></td>
						<td><a href="action/doDelete.php?id=<?php echo $row['empno']; ?>">Delete</a></td>
					</tr>
					<?php	
				}
				echo "</table>";
			}
		}
		mysqli_close($link);
	?>
</body>
</html>